**To cancel an active export task**

This example cancels an active export task with the task ID export-i-fgelt0i7. If the command succeeds, no output is returned.

Command::

  aws ec2 cancel-export-task --export-task-id export-i-fgelt0i7
